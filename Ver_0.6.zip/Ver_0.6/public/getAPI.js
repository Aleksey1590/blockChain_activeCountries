$.ajax({url: "/getTX", dataType:'json' }).done(
	function(imARandomName){
		$('#relayIP').text(imARandomName['txJS']['txs'][0]['relayed_by']);
})

		// $.ajax({url: "/getCountry", dataType:'json' }).done(
		// 	function(imARandomName2){
		// 		$('#country').text(imARandomName2['geoJSON']['country']);
		// 				})



// $.ajax({url: "/idCountry", dataType:'json' }).done(
// 	function(imARandomName3){
// 		$('#country').text(imARandomName3["reply"]["country"])
// })



// $.ajax({url: "/openJSON", dataType:'json' }).done(
// 		function(imARandomName2){
// 			$('#country').text(imARandomName2["Hello"]);
		
// 	})

// $.getJSON("countries.json", function(json) {
//     console.log(json); // this will show the info it in firebug console 
// });