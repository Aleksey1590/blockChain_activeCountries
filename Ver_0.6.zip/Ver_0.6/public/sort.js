var countriesJSON = require('countries.json');
var myObjJSON;

console.log(myObjJSON);
// var myObj = 
//   myObjJSON,
//   keys = [],
//   k, 
//   i, 
//   len;

// for (k in myObj) {
//   if (myObj.hasOwnProperty(k)) {
//     keys.push(k);
//   }
// }

// keys.sort();

// len = keys.length;

// for (i = 0; i < len; i++) {
//   k = keys[i];
//   console.log(k + ':' + myObj[k]);
// }