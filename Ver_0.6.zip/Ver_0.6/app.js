var express = require('express');
var request = require('request');
var app = express();
var WebSocket = require('ws');


var countriesJSON = require('./public/countries.json'); //(with path)
var fs = require('fs');



app.use('/', express.static('./public'));




//API testing 
// function getTXs (req, response) {
// 	console.log("getTXs starts to work.  ");
// 	console.log(" ");

// 	fetchTx(function(body) {
// 		var ip = body["txs"][0]["relayed_by"];
// 		fetchGeoIp(ip, function(body) {
// 			console.log(body);
// 			response.send("done!");
// 		})
// 	});
// }

function startWebSocket(){
	//Websocketing
	//var bciSocket = new WebSocket("ws://echo.websocket.org/");

	var bciSocket = new WebSocket("wss://ws.blockchain.info/inv");
	
	console.log("Websocket created successfully");


	bciSocket.onopen = function() {
		console.log("Connected successfully");
		console.log("");
		bciSocket.send('{"op": "unconfirmed_sub"}');
	};




	bciSocket.onmessage = function(event) {
		var msgJSON = JSON.parse(event.data);
		var ip = msgJSON['x']['relayed_by'];
		console.log("Received data: " + ip);


		fetchGeoIp(ip, function(body) {
			var countryPLUS = body["country"]
			console.log(countryPLUS);
			updateCountryRating(countryPLUS);
			//console.log(countriesJSON);
			//response.send("done!");
		});
	};

	
		

	bciSocket.onerror = function(error) {
	  console.log("Error: " + error.message);
	};	

	bciSocket.onclose = function(event) {
	  if (event.wasClean) {
	    console.log('Connection closed successfully');
	  } 
	  else {
	    console.log('Connection abrupted'); // 
	  }
	  console.log('Event code: ' + event.code + ' ; Reason: ' + event.reason);
	};

}



function fetchTx(callback) {
	request('https://blockchain.info/unconfirmed-transactions?format=json', handleTXsResponse.bind(null, callback));	
}

function fetchGeoIp(ip, callback) {
	//console.log("fetching geoip information for " + ip);
	var sendReq = "http://ip-api.com/json/".concat(ip);
	request(sendReq, handleGeoReply.bind(null, callback));	
}

function handleGeoReply (callback, error, response, body){
	// console.log("handleGeoReply starts to work. ");
	// console.log(" ");
	if (error) {
		callback(null, error)
	} else if (response.statusCode == 200) {
		var geoReply = JSON.parse(body);
		callback(geoReply, null);
  	} else {
  		callback(null, "Something weird happened");
  	}
}

function handleTXsResponse (callback, error, response, body) {
		
	if (error) {
			callback(null, error)
	} else if (response.statusCode == 200) {
		var txs = JSON.parse(body);
		callback(txs, null);
  	} else {
  		callback(null, "Something weird happened");
  	}
}











function updateCountryRating(country){
	//console.log("Starting Updating");
	for (let i=0; i<countriesJSON.length; i++){
		//console.log("Checking country - " + i);
		if (countriesJSON[i].name === country){
			countriesJSON[i].counter++;
			console.log("Update successfull of country - " + i);
			console.log("Current counter of country " + countriesJSON[i].name + " is " + countriesJSON[i].counter);
			//var file = require(countriesJSON);
			fs.writeFile('./public/countries.json', JSON.stringify(countriesJSON), function (err) {
  				if (err) return console.log(err);
			});
			//sortCountries(countriesJSON);
			return;
		}
	}
}





function sortObj(){

	var myObj = 
	  {
	  	'b': 'foo',
	  	'c': 'bar',
	  	'a': 'baz'
	  },
	  keys = [],
	  k, 
	  i, 
	  len;

	for (k in myObj) {
	  if (myObj.hasOwnProperty(k)) {
	    keys.push(k);
	  }
	}

	keys.sort();

	len = keys.length;

	for (i = 0; i < len; i++) {
	  k = keys[i];
	  console.log(k + ':' + myObj[k]);
	}
}

app.get('/getTX', startWebSocket);
// app.get('/getTX', sortObj);

app.listen(3000);

console.log('Listening to 3000');
console.log('_____');


