cd /Users/oleksiydubiletblockchain/Documents/activeCountries/Ver_0.6 ;
node app.js