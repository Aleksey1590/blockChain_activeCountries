cd /Users/oleksiydubiletblockchain/Documents/activeCountries/Ver_0.7 ;
node app.js